package td2.Forum;

public interface Composant {
}
