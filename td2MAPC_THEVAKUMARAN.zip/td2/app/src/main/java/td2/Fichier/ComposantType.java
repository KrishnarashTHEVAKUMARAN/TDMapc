package td2.Fichier;

public enum ComposantType {
    REPERTOIRE, FICHIER
}
